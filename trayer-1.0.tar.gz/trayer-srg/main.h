#include "panel.h"

int tray_constructor(panel *p);
void tray_destructor(panel *p);

