#include <gdk/gdkx.h>
#include <gdk/gdk.h>

Display* gdk_helper_display();
